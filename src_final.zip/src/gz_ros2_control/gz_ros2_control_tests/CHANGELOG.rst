^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gz_ros2_control_tests
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.17 (2025-09-29)
-------------------

0.7.16 (2025-08-18)
-------------------
* Provide force-torque sensor data through gz_system to controller_manager - fixes to original PR for Humble (`#637 <https://github.com/ros-controls/gz_ros2_control/issues/637>`_)
* Contributors: Bartłomiej Krajewski

0.7.15 (2025-05-23)
-------------------

0.7.14 (2025-04-21)
-------------------

0.7.13 (2025-04-04)
-------------------
* Add shim to deprecated ign_ros2_control_demos package (`#524 <https://github.com/ros-controls/gz_ros2_control/issues/524>`_)
* Backport updates to demos and tests (`#399 <https://github.com/ros-controls/gz_ros2_control/issues/399>`_, `#485 <https://github.com/ros-controls/gz_ros2_control/issues/485>`_, `#486 <https://github.com/ros-controls/gz_ros2_control/issues/486>`_, `#498 <https://github.com/ros-controls/gz_ros2_control/issues/498>`_, `#517 <https://github.com/ros-controls/gz_ros2_control/issues/517>`_) (`#522 <https://github.com/ros-controls/gz_ros2_control/issues/522>`_)
* Rename ign to gz (backport `#67 <https://github.com/ros-controls/gz_ros2_control/issues/67>`_) (`#515 <https://github.com/ros-controls/gz_ros2_control/issues/515>`_)
* Contributors: Christoph Fröhlich
