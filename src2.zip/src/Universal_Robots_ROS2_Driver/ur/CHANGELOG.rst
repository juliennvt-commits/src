^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ur
^^^^^^^^^^^^^^^^^^^^^^^^

2.6.0 (2025-03-17)
------------------

2.5.2 (2025-01-21)
------------------

2.5.1 (2024-12-21)
------------------

2.5.0 (2024-12-18)
------------------
* Update package maintainers (backport of `#1203 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/1203>`_)
* Contributors: mergify[bot]

2.2.16 (2024-10-28)
-------------------

2.2.15 (2024-07-26)
-------------------

2.2.14 (2024-07-01)
-------------------

2.2.13 (2024-06-17)
-------------------

2.2.12 (2024-05-16)
-------------------

2.2.11 (2024-04-08)
-------------------

2.2.10 (2024-01-03)
-------------------

2.2.9 (2023-09-22)
------------------

2.2.8 (2023-06-26)
------------------

2.2.7 (2023-06-02)
------------------

2.2.6 (2022-11-28)
------------------

2.2.5 (2022-11-19)
------------------

2.2.4 (2022-10-07)
------------------

2.2.3 (2022-07-27)
------------------

2.2.2 (2022-07-19)
------------------

2.2.1 (2022-06-27)
------------------

2.2.0 (2022-06-20)
------------------
* wip
* Rework bringup (`#403 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/403>`_)
  * Copy all bringup files to ur_robot_driver
  * Update documentation to use launchfiles from ur_robot_driver
  * Add deprecation warnings for ur_bringup
  * Add ``ur`` metapackage
  * Added deprecation warning to toplevel README
  * Added meta package to CI checks
* Contributors: Felix Exner

* Rework bringup (`#403 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/403>`_)
* Contributors: Felix Exner

0.0.3 (2020-10-29)
------------------
